# address configuration for running test

LOCAL_IF="igb0"

LOCAL_ADDR6="2001:630:42:110:ae1f:6bff:fe46:9eda"
LOCAL_MAC="ac:1f:6b:46:9e:da"

REMOTE_ADDR6="2001:630:42:110:2a0:98ff:fe02:684"
REMOTE_MAC="00:a0:98:02:06:84"
